//
//  ViewController.swift
//  Calculator_laila
//
//  Created by administrator on 11/12/2021.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet var ResultLabel: UILabel!
    
    var Operation: String = ""
    
    var Num1: String = ""
    var Num2: String = ""
    
    var SignNum1: String = ""
    var SignNum2: String = ""
    
    var DecimalNum1:String = ""
    var DecimalNum2:String = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        ResultLabel.text = "0"
    }

    //Actions for Numbers
    @IBAction func ButtonNumber0(_ sender: UIButton) {
        
        guard let Title = sender.titleLabel?.text else{return}
        
        if Operation.isEmpty{
            Num1 = Num1 + Title
            ResultLabel.text = Num1
            
        }else{
            Num2 = Num2 + Title
            ResultLabel.text = Num2
        }
        
    }
    
    @IBAction func ButtonNumber1(_ sender: UIButton) {
        
        guard let Title = sender.titleLabel?.text else{return}
        
        if Operation.isEmpty{
            Num1 = Num1 + Title
            ResultLabel.text = Num1
            
        }else{
            Num2 = Num2 + Title
            ResultLabel.text = Num2
        }
        
    }
    
    @IBAction func ButtonNumber2(_ sender: UIButton) {
        
        guard let Title = sender.titleLabel?.text else{return}
        
        if Operation.isEmpty{
            Num1 = Num1 + Title
            ResultLabel.text = Num1
            
        }else{
            Num2 = Num2 + Title
            ResultLabel.text = Num2
        }
        
    }
    
    @IBAction func ButtonNumber3(_ sender: UIButton) {
        
        guard let Title = sender.titleLabel?.text else{return}
        
        if Operation.isEmpty{
            Num1 = Num1 + Title
            ResultLabel.text = Num1
            
        }else{
            Num2 = Num2 + Title
            ResultLabel.text = Num2
        }
        
    }
    
    @IBAction func ButtonNumber4(_ sender: UIButton) {
        
        guard let Title = sender.titleLabel?.text else{return}
        
        if Operation.isEmpty{
            Num1 = Num1 + Title
            ResultLabel.text = Num1
            
        }else{
            Num2 = Num2 + Title
            ResultLabel.text = Num2
        }
        
    }
    
    @IBAction func ButtonNumber5(_ sender: UIButton) {
        
        guard let Title = sender.titleLabel?.text else{return}
        
        if Operation.isEmpty{
            Num1 = Num1 + Title
            ResultLabel.text = Num1
            
        }else{
            Num2 = Num2 + Title
            ResultLabel.text = Num2
        }
    }
    
    @IBAction func ButtonNumber6(_ sender: UIButton) {
        
        guard let Title = sender.titleLabel?.text else{return}
        
        if Operation.isEmpty{
            Num1 = Num1 + Title
            ResultLabel.text = Num1
            
        }else{
            Num2 = Num2 + Title
            ResultLabel.text = Num2
        }
        
    }
    
    @IBAction func ButtonNumber7(_ sender: UIButton) {
        
        guard let Title = sender.titleLabel?.text else{return}
        
        if Operation.isEmpty{
            Num1 = Num1 + Title
            ResultLabel.text = Num1
            
        }else{
            Num2 = Num2 + Title
            ResultLabel.text = Num2
        }
        
    }
    
    @IBAction func ButtonNumber8(_ sender: UIButton) {
        
        guard let Title = sender.titleLabel?.text else{return}
        
        if Operation.isEmpty{
            Num1 = Num1 + Title
            ResultLabel.text = Num1
            
        }else{
            Num2 = Num2 + Title
            ResultLabel.text = Num2
        }
        
    }
    
    @IBAction func ButtonNumber9(_ sender: UIButton) {
        
        guard let Title = sender.titleLabel?.text else{return}
        
        if Operation.isEmpty{
            Num1 = Num1 + Title
            ResultLabel.text = Num1
            
        }else{
            Num2 = Num2 + Title
            ResultLabel.text = Num2
        }
        
    }
    //
    @IBAction func DecimalButton(_ sender: UIButton) {
        
        if Operation.isEmpty && DecimalNum1.isEmpty{
            
            DecimalNum1 = "."
            Num1 = Num1 + DecimalNum1
            ResultLabel.text = Num1
            
        } else if !Operation.isEmpty && DecimalNum2.isEmpty{
            
            DecimalNum2 = "."
            Num2 = Num2 + DecimalNum2
            ResultLabel.text = Num2
        }
        
    }
    
    @IBAction func ButtonClean(_ sender: UIButton) {
        
        ResultLabel.text = "0"
        
        Operation = ""
        
        Num1 = ""
        Num2 = ""
        
        SignNum1 = ""
        SignNum2 = ""
        
        DecimalNum1 = ""
        DecimalNum2 = ""
        
    }
    
    @IBAction func SignButton(_ sender: UIButton) {
        
        if Operation.isEmpty {
            if sender.tag == 1{
                SignNum1 = "-"
                sender.tag = 2
            }else{
                SignNum1 = ""
                sender.tag = 1
            }
            ResultLabel.text = SignNum1 + Num1
        }else {
            if sender.tag == 1{
                SignNum2 = "-"
                sender.tag = 2
            }else{
                SignNum2 = ""
                sender.tag = 1
            }
            ResultLabel.text = SignNum2 + Num2
        }
        
    }
    
    //Operation
    @IBAction func ModOperationButton(_ sender: UIButton) {
        if !Num1.isEmpty && Operation.isEmpty {
            
            Operation = "%"
            
        }
    }
    
    @IBAction func DivOperationButton(_ sender: UIButton) {
        
        if !Num1.isEmpty && Operation.isEmpty {
            
            Operation = "/"
            
        }
        
    }
    
    @IBAction func MulOperationButton(_ sender: UIButton) {
        
        if !Num1.isEmpty && Operation.isEmpty {
            
            Operation = "*"
            
        }
    }
    
    @IBAction func SubOperationButton(_ sender: UIButton) {
        
        if !Num1.isEmpty && Operation.isEmpty {
            
            Operation = "-"
        }
    }
    
    @IBAction func AddOperationButton(_ sender: UIButton) {
        
        if !Num1.isEmpty && Operation.isEmpty {
            
            Operation = "+"
        
        }
    }
    
    //calculate result
    @IBAction func EqoulButton(_ sender: UIButton) {
        
        if !Num1.isEmpty && !Operation.isEmpty && !Num2.isEmpty{
            
            Num1 = SignNum1 + Num1
            Num2 = SignNum2 + Num2
            
            guard let N1 = Double(Num1),let  N2 = Double(Num2)else {return}
            
            switch Operation{
            case "+":
                ResultLabel.text = "\(N1 + N2)"
            case "-":
                ResultLabel.text = "\(N1 - N2)"
            case "*":
                ResultLabel.text = "\(N1 * N2)"
            case "/":
                if N2 != 0{
                    ResultLabel.text = "\(N1 / N2)"}
                else{
                    ResultLabel.text = "0"}
            case "%":
                ResultLabel.text = "\(Int(N1) % Int(N2))"
                
            default:
                ResultLabel.text = "0"
            }
            if let Result = ResultLabel.text{
                Num1 = Result
            }
          
            Num2 = ""
            Operation = ""
            SignNum2 = ""
            
        }
        
    }
    
}

